package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onest.webshop.bean.Book;
import com.onest.webshop.common.DbConnection;

public class BookDao {

	public List<Book> selectAll() throws SQLException {
		List<Book> booklist = new ArrayList<Book>();
		Book book = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from book");
			rs = ps.executeQuery();
			while(rs.next()) {
				book = new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_image(rs.getString("book_image"));
				book.setBook_auth(rs.getString("book_auth"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBook_introduce(rs.getString("book_introduce"));
				book.setBook_price(rs.getInt("book_price"));
				book.setType_name(rs.getString("type_name"));
				book.setType_id(rs.getInt("type_id"));
				booklist.add(book);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			rs.close();
			ps.close();
			connection.close();
		}
		
		return booklist;
	}
	
	
	public Book bookdetail(int book_id) throws SQLException {
		Book book = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from book where book_id = ?");
			ps.setInt(1, book_id);
			rs = ps.executeQuery();
			while(rs.next()) {
				book = new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_image(rs.getString("book_image"));
				book.setBook_auth(rs.getString("book_auth"));
				book.setBook_publisher(rs.getString("book_publisher"));
				book.setBook_introduce(rs.getString("book_introduce"));
				book.setBook_price(rs.getInt("book_price"));
				book.setType_name(rs.getString("type_name"));
				book.setType_id(rs.getInt("type_id"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			rs.close();
			ps.close();
			connection.close();
		}
		return book;
	}
	
	public Boolean bookUpdate(int book_id,String book_name, String book_auth,String book_publisher,int book_price,String book_introduce,String type_name) throws SQLException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		Boolean b = false;
		try {
			ps=connection.prepareStatement("update book set book_name = ?,book_auth = ?,book_publisher = ?,book_price = ?,type_name=?,book_introduce = ? where book_id =?");
			ps.setString(1, book_name);
			ps.setString(2, book_auth);
			ps.setString(3, book_publisher);
			ps.setInt(4, book_price);
			ps.setString(5, type_name);
			ps.setString(6, book_introduce);
			ps.setInt(7, book_id);
			b = ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ps.close();
		connection.close();
		return b;
		
	}
	
	public Boolean bookDelete(int book_id) throws SQLException {
		Boolean b = false;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps=connection.prepareStatement("delete from book where book_id=?");
			b = ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ps.close();
		connection.close();
		return b;
	}
	
	public Boolean bookAdd(String book_name, String book_auth,String book_publisher,int book_price,String type_name) throws SQLException {
		Boolean b = false;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps=connection.prepareStatement("inser into book(book_name,book_auth,book_price,book_introduce,type_name) "
					+ "values(?,?,?,?,?,?)");
			ps.setString(1,book_name );
			ps.setString(2,book_auth);
			ps.setString(3,book_publisher);
			ps.setInt(4,book_price);
			ps.setString(5, type_name);
			b = ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ps.close();
		connection.close();
		return b;
	}
	
}
