package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.bean.User;
import com.onest.webshop.common.DbConnection;

public class UserDao {

	public User login(int user_id,String user_password) throws SQLException{
		User user = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps=connection.prepareStatement("select * from user where user_id=? and user_password=?");
			ps.setInt(1, user_id);
			ps.setString(2, user_password);
			rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setUser_id(user_id);
				user.setUser_name(rs.getString("user_name"));
				user.setUser_password(user_password);
				user.setUser_sex(rs.getString("user_sex"));
				user.setUser_birthday(rs.getDate("user_birthday"));
				user.setUser_introduce(rs.getString("user_introduce"));
			}
			rs.close();
		    ps.close();
		    connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public Boolean register(String user_name,String user_password,String user_sex,Date user_birthday,String user_introduce) throws SQLException{
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps=connection.prepareStatement("insert into user(user_name,user_password,user_sex, user_birthday,user_introduce)"
					+ " values(?,?,?,?,?)");
			ps.setString(1, user_name);
			ps.setString(2, user_password);
			ps.setString(3, user_sex);
			ps.setDate(4,new java.sql.Date(user_birthday.getTime()));
			ps.setString(5, user_introduce);
			ps.execute();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public List<User> selectAll() throws SQLException {
		List<User> userlist = new ArrayList<User>();
		
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from user");
			rs = ps.executeQuery();
			while(rs.next()) {
				User user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setUser_name(rs.getString("user_name"));
				user.setUser_password(rs.getString("user_password"));
				user.setUser_sex(rs.getString("user_sex"));
				user.setUser_birthday(rs.getDate("user_birthday"));
				user.setUser_introduce(rs.getString("user_introduce"));
				userlist.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userlist;
	}
	
	public Boolean update(Integer user_id,String user_name,String user_password,String user_sex,Date user_birthday,String user_introduce) throws SQLException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement("update user set user_name=?,user_password=?,user_sex=?,user_birthday=?,user_introduce=? where user_id=?");
			ps.setString(1,user_name );
			ps.setString(2, user_password);
			ps.setString(3, user_sex);
			ps.setDate(4, (java.sql.Date) user_birthday);
			ps.setString(5, user_introduce);
			ps.setInt(6, user_id);
			ps.execute();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			ps.close();
			connection.close();
		}
		
		return false;
	}
	
	public User userById(int user_id) {
		User user = new User();
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps=connection.prepareStatement("select * from user where user_id=?");
			ps.setInt(1, user_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				user = new User();
				user.setUser_id(user_id);
				user.setUser_name(rs.getString("user_name"));
				user.setUser_password(rs.getString("user_password"));
				user.setUser_sex(rs.getString("user_sex"));
				user.setUser_birthday(rs.getDate("user_birthday"));
				user.setUser_introduce(rs.getString("user_introduce"));
			}
			rs.close();
		    ps.close();
		    connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return user;
		
	}
	
}
