package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onest.webshop.bean.Order;
import com.onest.webshop.bean.OrderDetail;
import com.onest.webshop.common.DbConnection;

public class OrderDao {

	public List<Order> selectAll() throws SQLException {
		List<Order> orderlist = new ArrayList<Order>();
		Order order = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from order");
			rs = ps.executeQuery();
			while(rs.next()) {
				order = new Order();
				order.setUser_id(rs.getInt("user_id"));
				order.setUser_name(rs.getString("user_name"));
				order.setOrder_id(rs.getInt("order_id"));
				orderlist.add(order);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rs.close();
		ps.close();
		connection.close();
		return orderlist;
	}
	
	public List<OrderDetail> selectUser(int user_id) throws SQLException {
		List<OrderDetail> uorderlist = new ArrayList<OrderDetail>();
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from order_detail where user_id = ? ");
			ps.setInt(1, user_id);
			rs = ps.executeQuery();
			while(rs.next()) {
				OrderDetail orderd = new OrderDetail();
				orderd.setOrder_id(rs.getInt("order_id"));
				orderd.setBook_id(rs.getInt("book_id"));
				orderd.setBook_name(rs.getString("book_name"));
				orderd.setBook_price(rs.getInt("book_price"));
				uorderlist.add(orderd);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rs.close();
		ps.close();
		connection.close();
		return uorderlist;
	}
	
	public void orderAdd(int user_id,String user_name) throws SQLException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps=connection.prepareStatement("insert into order(user_id,user_name) "
					+ "values(?,?)");
			ps.setInt(1, user_id);
			ps.setString(2, user_name);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ps.close();
		connection.close();
		
	}
	
}
