package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onest.webshop.bean.Type;
import com.onest.webshop.common.DbConnection;

public class TypeDao {

	public List<Type> selectAll() throws SQLException {
		List<Type> typelist = new ArrayList<Type>();
		
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from type");
			rs = ps.executeQuery();
			while(rs.next()) {
				Type type = new Type();
				type.setType_id(rs.getInt("type_id"));
				type.setType_name(rs.getString("type_name"));
				typelist.add(type);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return typelist;
	}
	
	
}
