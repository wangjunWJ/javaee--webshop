package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.common.DbConnection;

public class AdminDao {

	public Admin login(String admin_name,String admin_password) throws SQLException{
		Admin admin = null;
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps=connection.prepareStatement("select * from admin where admin_name=? and admin_password=?");
			ps.setString(1, admin_name);
			ps.setString(2, admin_password);
			rs = ps.executeQuery();
			if(rs.next()) {
				admin = new Admin();
				admin.setAdmin_id(rs.getInt("admin_id"));
				admin.setAdmin_name(admin_name);
				admin.setAdmin_password(admin_password);
				admin.setAdmin_img(rs.getString("admin_img"));
				admin.setAdmin_sex(rs.getString("admin_sex"));
				admin.setAdmin_tel(rs.getString("admin_tel"));
				admin.setAdmin_introduce(rs.getString("admin_introduce"));
			}
			rs.close();
		    ps.close();
		    connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			
		}
		return admin;
	}
	
	
	public Boolean update(Integer admin_id,String admin_name,String admin_password,String admin_sex,String admin_tel,String admin_introduce) throws SQLException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement("update admin set admin_name=?,admin_password=?,admin_sex=?,admin_tel=?,admin_introduce=? where admin_id=?");
			ps.setString(1, admin_name);
			ps.setString(2, admin_password);
			ps.setString(3, admin_sex);
			ps.setString(4, admin_tel);
			ps.setString(5, admin_introduce);
			ps.setInt(6, admin_id);ps.execute();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			ps.close();
			connection.close();
		}
		
		return false;
	}
}
