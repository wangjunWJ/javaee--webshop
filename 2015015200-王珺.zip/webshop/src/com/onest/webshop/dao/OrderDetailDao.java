package com.onest.webshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onest.webshop.bean.OrderDetail;
import com.onest.webshop.common.DbConnection;

public class OrderDetailDao {

	public List<OrderDetail> selectAll() {
		List<OrderDetail> orderdetaillist = new ArrayList<OrderDetail>();

		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = connection.prepareStatement("select * from order_detail");
			rs = ps.executeQuery();
			while(rs.next()) {
				OrderDetail orderdetail = new OrderDetail();
				orderdetail.setUser_id(rs.getInt("user_id"));
				orderdetail.setOrder_id(rs.getInt("order_id"));
				orderdetail.setBook_id(rs.getInt("book_id"));
				orderdetail.setBook_name(rs.getString("book_name"));
				orderdetail.setBook_price(rs.getInt("book_price"));
				orderdetaillist.add(orderdetail);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				ps.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return orderdetaillist;
	}
	
	
	public void orderDetailAdd(int user_id,int book_id,String book_name,int book_price) throws SQLException {
		Connection connection = DbConnection.getConnection();
		PreparedStatement ps = null;
		try {
			ps=connection.prepareStatement("insert into order_detail(user_id,book_id,book_name,book_price)"
					+ " values(?,?,?,?)");
			ps.setInt(1, user_id);
			ps.setInt(2, book_id);
			ps.setString(3, book_name);
			ps.setInt(4, book_price);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ps.close();
		connection.close();
	}
}
