package com.onest.webshop.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onest.webshop.dao.AdminDao;

/**
 * Servlet implementation class AdminUpdateServlet
 */
@WebServlet("/AdminUpdateServlet")
public class AdminUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String id =request.getParameter("admin_id");
		Integer admin_id = Integer.parseInt(id);
		String admin_name =request.getParameter("admin_name");
		String admin_password =request.getParameter("admin_password");
		String admin_sex =request.getParameter("admin_sex");
		String admin_tel =request.getParameter("admin_tel");
		String admin_introduce =request.getParameter("admin_introduce");
		
		
		AdminDao ad = new AdminDao();
		try {
			Boolean b = ad.update(admin_id, admin_name, admin_password, admin_sex, admin_tel, admin_introduce);
			if(b) {
				response.sendRedirect("admin/show/update_result.jsp");
				
			} else {
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
