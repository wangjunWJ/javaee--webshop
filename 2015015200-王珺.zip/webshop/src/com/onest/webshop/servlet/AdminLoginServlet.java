package com.onest.webshop.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.service.AdminService;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String admin_name = request.getParameter("admin_name");
		String admin_password = request.getParameter("admin_password");
		
		AdminService as = new AdminService();
		Admin admin = null;
		try {
			admin = as.login(admin_name, admin_password);
			if(admin != null) {
				request.getSession().setAttribute("admin",admin);
				response.sendRedirect("admin/main.jsp");
				//request.getRequestDispatcher("admin/main.jsp").forward(request,response);
			}else {
				request.getSession().setAttribute("errorMsg","�û������������");
		    	request.getRequestDispatcher("admin/login.jsp").forward(request,response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
