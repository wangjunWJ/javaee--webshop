package com.onest.webshop.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onest.webshop.bean.Book;
import com.onest.webshop.bean.Order;
import com.onest.webshop.bean.OrderDetail;
import com.onest.webshop.dao.BookDao;
import com.onest.webshop.dao.OrderDao;
import com.onest.webshop.dao.OrderDetailDao;

/**
 * Servlet implementation class UserShopOrderServlet
 */
@WebServlet("/UserShopOrderServlet")
public class UserShopOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserShopOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String id = request.getParameter("user_id");
		int user_id = Integer.parseInt(id);
		String user_name = request.getParameter("user_name");
		
		BookDao bd = new BookDao();
		OrderDao od = new OrderDao();
		OrderDetailDao odd = new OrderDetailDao();
		
		Order order = null;
		Book book = null;
		OrderDetail orderdetail = null;
		List<OrderDetail> odlist = new ArrayList<OrderDetail>();
		
		String[] items = request.getParameterValues("item") ;
		if(items != null && items.length>0) {
			for(int i = 0; i < items.length; i ++) {
				int book_id = Integer.parseInt(items[i]);
				try {
					book = bd.bookdetail(book_id);
					odd.orderDetailAdd(user_id, book_id, book.getBook_name(), book.getBook_price());
					orderdetail = new OrderDetail();
					orderdetail.setUser_id(user_id);
					orderdetail.setBook_id(book_id);
					orderdetail.setBook_name(book.getBook_name());
					orderdetail.setBook_price(book.getBook_price());
					odlist.add(orderdetail);
					
					od.orderAdd(user_id, user_name);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			request.setAttribute("odlist", odlist);
			request.getRequestDispatcher("succeed.jsp").forward(request, response);
		}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
