package com.onest.webshop.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.bean.Book;
import com.onest.webshop.bean.User;
import com.onest.webshop.service.AdminService;
import com.onest.webshop.service.BookService;
import com.onest.webshop.service.UserService;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String id = request.getParameter("user_id");
		int user_id = Integer.parseInt(id);
		String user_password = request.getParameter("user_password");
		BookService bs = new BookService();
		UserService as = new UserService();
		List<Book> booklist= new ArrayList<Book>();
		User user = null;
		try {
			user = as.login(user_id, user_password);
			booklist = bs.selectAll();
			if(user != null) {
				request.getSession().setAttribute("booklist",booklist);
				request.getSession().setAttribute("user_id",user_id);
				request.getSession().setAttribute("user",user);
				response.sendRedirect("main.jsp");
				//request.getRequestDispatcher("admin/main.jsp").forward(request,response);
			}else {
		    	request.getRequestDispatcher("error.jsp").forward(request,response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
