package com.onest.webshop.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onest.webshop.service.BookService;

/**
 * Servlet implementation class BookUpdateReServlet
 */
@WebServlet("/BookUpdateReServlet")
public class BookUpdateReServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookUpdateReServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String id = request.getParameter("book_id");
		int book_id = Integer.parseInt(id);
		String book_name = request.getParameter("book_name");
		String book_auth = request.getParameter("book_auth");
		String book_publisher = request.getParameter("book_publisher");
		String price = request.getParameter("book_price");
		int book_price = Integer.parseInt(price);
		String book_introduce = request.getParameter("book_introduce");
		String type_name = request.getParameter("type_name");
		
		BookService bs = new BookService();
		try {
			Boolean b = bs.bookUpdate(book_id, book_name, book_auth, book_publisher, book_price, book_introduce, type_name);
			if(b) {
				response.sendRedirect("admin/show/book_list.jsp");
				
			} else {
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
