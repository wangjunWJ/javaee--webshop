package com.onest.webshop.bean;

public class Book {

	private Integer book_id;
	private String book_name;
	private String book_image;
	private String book_auth;
	private String book_publisher;
	private String book_introduce;
	private Integer book_price;
	private String type_name;
	private Integer type_id;
	public Integer getBook_id() {
		return book_id;
	}
	public void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_image() {
		return book_image;
	}
	public void setBook_image(String book_image) {
		this.book_image = book_image;
	}
	public String getBook_auth() {
		return book_auth;
	}
	public void setBook_auth(String book_auth) {
		this.book_auth = book_auth;
	}
	public String getBook_publisher() {
		return book_publisher;
	}
	public void setBook_publisher(String book_publisher) {
		this.book_publisher = book_publisher;
	}
	public String getBook_introduce() {
		return book_introduce;
	}
	public void setBook_introduce(String book_introduce) {
		this.book_introduce = book_introduce;
	}
	public Integer getBook_price() {
		return book_price;
	}
	public void setBook_price(Integer book_price) {
		this.book_price = book_price;
	}
	public String getType_name() {
		return type_name;
	}
	public void setType_name(String type_name) {
		this.type_name = type_name;
	}
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
}
