package com.onest.webshop.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onest.webshop.bean.Type;
import com.onest.webshop.dao.TypeDao;

public class TypeService {

	public List<Type> selectAll() {
		TypeDao td = new TypeDao();
		List<Type> typelist = new ArrayList<Type>();
		try {
			typelist = td.selectAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return typelist;
	}
	
}
