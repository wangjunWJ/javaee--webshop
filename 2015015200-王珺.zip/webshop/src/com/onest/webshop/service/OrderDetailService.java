package com.onest.webshop.service;

import java.sql.SQLException;
import java.util.List;

import com.onest.webshop.bean.OrderDetail;
import com.onest.webshop.dao.OrderDetailDao;

public class OrderDetailService {

	public List<OrderDetail> selectAll() {
		
		OrderDetailDao odd = new OrderDetailDao();
		List<OrderDetail> orderdetaillist = odd.selectAll();
		return orderdetaillist;
		
	}
	
	public void orderDetailAdd(int user_id,int book_id,String book_name,int book_price) {
		OrderDetailDao odd = new OrderDetailDao();
		try {
			odd.orderDetailAdd(user_id, book_id, book_name, book_price);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
