package com.onest.webshop.service;

import java.sql.SQLException;
import java.util.List;

import com.onest.webshop.bean.Order;
import com.onest.webshop.bean.OrderDetail;
import com.onest.webshop.dao.OrderDao;

public class OrderService {

	public List<Order> selectAll() throws SQLException {
		OrderDao od = new OrderDao();
		List<Order> orderlist = od.selectAll();
		return orderlist;
	}
	
	public List<OrderDetail> selectOrder(int user_id) throws SQLException {
		OrderDao od = new OrderDao();
		List<OrderDetail> userorder = od.selectUser(user_id);
		return userorder;
	}
	
	public void orderAdd(int user_id,String user_name) {
		OrderDao od = new OrderDao();
		try {
			od.orderAdd(user_id, user_name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
