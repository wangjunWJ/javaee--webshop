package com.onest.webshop.service;

import java.sql.SQLException;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.dao.AdminDao;

public class AdminService {

	public Admin login(String admin_name,String admin_password) throws SQLException {
		AdminDao ad = new AdminDao();
		Admin admin = ad.login(admin_name, admin_password);
		return admin;
	}
	
	
}
