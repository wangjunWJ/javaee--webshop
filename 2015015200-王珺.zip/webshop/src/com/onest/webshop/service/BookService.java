package com.onest.webshop.service;

import java.sql.SQLException;
import java.util.List;

import com.onest.webshop.bean.Book;
import com.onest.webshop.dao.BookDao;

public class BookService {

	public List<Book> selectAll() {
		BookDao bd = new BookDao();
		List<Book> booklist = null;
		try {
			booklist = bd.selectAll();
			return booklist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return booklist;
	}
	
	public Book bookdetail(int book_id) {
		BookDao bd = new BookDao();
		Book book = null;
		try {
			book = bd.bookdetail(book_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return book;
	} 
	
	public Boolean bookUpdate(int book_id,String book_name, String book_auth,String book_publisher,int book_price,String book_introduce,String type_name) throws SQLException {
		BookDao bd = new BookDao();
		Boolean b = bd.bookUpdate(book_id, book_name, book_auth, book_publisher, book_price, book_introduce, type_name);
		return b;
		
	}
	
	public Boolean bookDelete(int book_id) {
		BookDao bd = new BookDao();
		Boolean b = null;
		try {
			b = bd.bookDelete(book_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	
	public Boolean bookAdd(String book_name,String book_auth,String book_publisher,int book_price,String type_name) {
		BookDao bd = new BookDao();
		Boolean b = null;
		try {
			b = bd.bookAdd(book_name, book_auth, book_publisher, book_price, type_name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
}
