package com.onest.webshop.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.onest.webshop.bean.Admin;
import com.onest.webshop.bean.User;
import com.onest.webshop.dao.AdminDao;
import com.onest.webshop.dao.UserDao;

public class UserService {

	public List<User> selectAll() {
		UserDao ud = new UserDao();
		List<User> userlist = null;
		try {
			userlist = ud.selectAll();
			return userlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userlist;
	}
	
	public User login(int user_id,String user_password) throws SQLException {
		UserDao ad = new UserDao();
		User user = ad.login(user_id, user_password);
		return user;
	}
	
	public Boolean register(String user_name,String user_password,String user_sex,Date user_birthday,String user_introduce) {
		UserDao ud = new UserDao();
		
		Boolean b = false;
		try {
			b = ud.register(user_name, user_password, user_sex, user_birthday, user_introduce);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	
	public Boolean update(Integer user_id,String user_name,String user_password,String user_sex,Date user_birthday,String user_introduce) {
		UserDao ud = new UserDao();
		Boolean b = false;
		try {
			b=ud.register(user_name, user_password, user_sex, user_birthday, user_introduce);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	
	public User userById(int user_id) {
		UserDao ud = new UserDao();
		User user = ud.userById(user_id);
		return user;
	}
}
